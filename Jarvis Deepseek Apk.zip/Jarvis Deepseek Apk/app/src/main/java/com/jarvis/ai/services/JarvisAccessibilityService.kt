package com.jarvis.ai.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
        
        fun performClick(x: Float, y: Float): Boolean {
            return instance?.dispatchGesture(createTap(x, y), null, null) ?: false
        }
        
        private fun createTap(x: Float, y: Float): GestureDescription {
            val path = Path()
            path.moveTo(x, y)
            return GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
                .build()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        // Handle accessibility events if needed
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun findAndClickButton(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findButton(root, text)?.let { button ->
            val bounds = android.graphics.Rect()
            button.getBoundsInScreen(bounds)
            performClick(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        } ?: false
    }

    private fun findButton(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) {
            return node
        }
        if (node.contentDescription?.toString()?.contains(text, ignoreCase = true) == true) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findButton(child, text)
            if (result != null) return result
        }
        return null
    }

    fun getScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        extractText(root, sb)
        return sb.toString()
    }

    private fun extractText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.toString()?.let {
            sb.append(it).append("\n")
        }
        node.contentDescription?.toString()?.let {
            sb.append(it).append("\n")
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                extractText(child, sb)
            }
        }
    }
}