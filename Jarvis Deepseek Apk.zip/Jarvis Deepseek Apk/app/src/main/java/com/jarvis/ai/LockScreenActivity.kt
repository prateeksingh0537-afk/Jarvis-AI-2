package com.jarvis.ai

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.jarvis.ai.services.VoiceRecognitionService
import com.jarvis.ai.utils.SystemHelper

class LockScreenActivity : Activity() {

    private lateinit var gifImageView: ImageView
    private lateinit var statusText: TextView
    private lateinit var systemHelper: SystemHelper
    private lateinit var powerManager: PowerManager
    private lateinit var keyguardManager: KeyguardManager
    
    private var isListening = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set flags to show over lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        
        setContentView(R.layout.activity_lock_screen)
        
        initializeViews()
        initializeHelpers()
        startVoiceService()
    }
    
    private fun initializeViews() {
        gifImageView = findViewById(R.id.gifJarvisLock)
        statusText = findViewById(R.id.textLockStatus)
        
        // Load lock screen GIF (bigger version)
        Glide.with(this)
            .asGif()
            .load(R.drawable.jarvis_lock_gif)
            .into(gifImageView)
    }
    
    private fun initializeHelpers() {
        systemHelper = SystemHelper(this)
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    }
    
    private fun startVoiceService() {
        val intent = Intent(this, VoiceRecognitionService::class.java)
        intent.putExtra("from_lock_screen", true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        isListening = true
        statusText.text = "बोलो, सुन रहा हूँ"
    }
    
    fun onVoiceCommandReceived(command: String) {
        // Process command without unlocking
        when {
            command.contains("unlock") || command.contains("खोल") -> {
                unlockDevice()
            }
            command.contains("flashlight") || command.contains("टॉर्च") -> {
                systemHelper.toggleFlashlight()
                speakResponse("कर दिया")
            }
            command.contains("volume") -> {
                if (command.contains("up") || command.contains("बढ़ा")) {
                    systemHelper.adjustVolume(true)
                } else if (command.contains("down") || command.contains("घटा")) {
                    systemHelper.adjustVolume(false)
                }
                speakResponse("कर दिया")
            }
            else -> {
                // For other commands, show that they need unlock
                speakResponse("इसके लिए अनलॉक करना पड़ेगा")
            }
        }
    }
    
    private fun unlockDevice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (keyguardManager.isKeyguardSecure) {
                // Show biometric prompt
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val biometricPrompt = BiometricPrompt.Builder(this)
                        .setTitle("Unlock Jarvis")
                        .setSubtitle("Face or fingerprint required")
                        .setNegativeButton("Cancel", mainExecutor) { dialog, which ->
                            speakResponse("Cancel kar diya")
                        }
                        .build()
                    
                    biometricPrompt.authenticate(
                        BiometricPrompt.CryptoObject(null),
                        CancellationSignal(),
                        mainExecutor,
                        object : BiometricPrompt.AuthenticationCallback() {
                            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                super.onAuthenticationSucceeded(result)
                                finish() // Close lock screen
                            }
                        }
                    )
                }
            } else {
                // No security, just finish
                finish()
            }
        }
    }
    
    private fun speakResponse(text: String) {
        systemHelper.speak(text)
    }
    
    override fun onBackPressed() {
        // Don't allow back press on lock screen
        // Just turn screen off
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            powerManager.run {
                if (isInteractive) {
                    goToSleep(SystemClock.uptimeMillis())
                }
            }
        }
    }
}