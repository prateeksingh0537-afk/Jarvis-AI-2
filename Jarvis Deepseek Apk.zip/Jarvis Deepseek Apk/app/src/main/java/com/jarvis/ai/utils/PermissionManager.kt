package com.jarvis.ai.utils

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.jarvis.ai.R

class PermissionManager(
    private val context: Context,
    private val launcher: ActivityResultContracts.RequestMultiplePermissions.launch
) {

    companion object {
        // All dangerous permissions needed
        val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.ACCESS_NOTIFICATION_POLICY,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.NFC,
            Manifest.permission.FLASHLIGHT
        )
    }

    fun hasMicrophonePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasAllPermissions(): Boolean {
        return REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestAllPermissions() {
        val missingPermissions = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (missingPermissions.isNotEmpty()) {
            launcher.launch(missingPermissions)
        }
    }

    fun requestMicrophonePermission() {
        launcher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }

    fun requestContactsPermission() {
        launcher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
    }

    fun requestCameraPermission() {
        launcher.launch(arrayOf(Manifest.permission.CAMERA))
    }

    fun requestLocationPermission() {
        launcher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                AlertDialog.Builder(context)
                    .setTitle("Floating Button Permission")
                    .setMessage("Jarvis को हर ऐप के ऊपर दिखने के लिए overlay permission चाहिए। Settings में जाकर ON कर दे।")
                    .setPositiveButton("Open Settings") { _, _ ->
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    fun requestNotificationAccess() {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        context.startActivity(intent)
    }

    fun requestUsageAccess() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        context.startActivity(intent)
    }

    fun requestBatteryOptimizationIgnore() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(intent)
        }
    }

    fun requestWriteSettings() {
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
        intent.data = Uri.parse("package:${context.packageName}")
        context.startActivity(intent)
    }

    fun requestDeviceAdmin() {
        val intent = Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(
            android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN,
            android.content.ComponentName(context, com.jarvis.ai.receivers.JarvisDeviceAdminReceiver::class.java)
        )
        intent.putExtra(
            android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Jarvis को screen lock/unlock करने के लिए Device Admin बनाना होगा"
        )
        context.startActivity(intent)
    }

    fun isDeviceAdminActive(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        val componentName = android.content.ComponentName(context, com.jarvis.ai.receivers.JarvisDeviceAdminReceiver::class.java)
        return dpm.isAdminActive(componentName)
    }

    fun showPermissionRationale(permission: String): String {
        return when (permission) {
            Manifest.permission.RECORD_AUDIO -> "तुझे सुनने के लिए माइक चाहिए।"
            Manifest.permission.READ_CONTACTS -> "कॉन्टैक्ट्स पढ़ने के लिए permission चाहिए।"
            Manifest.permission.CALL_PHONE -> "कॉल करने के लिए phone permission चाहिए।"
            Manifest.permission.CAMERA -> "फोटो खींचने के लिए कैमरा चाहिए।"
            Manifest.permission.ACCESS_FINE_LOCATION -> "लोकेशन के बिना रास्ता नहीं बता सकता।"
            else -> "ये permission जरूरी है।"
        }
    }
}