package com.jarvis.ai.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.jarvis.ai.utils.SystemHelper

class NotificationListener : NotificationListenerService() {

    private val TAG = "NotificationListener"
    private lateinit var systemHelper: SystemHelper

    override fun onCreate() {
        super.onCreate()
        systemHelper = SystemHelper(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        val notification = sbn.notification
        val extras = notification.extras
        
        val title = extras.getString(android.app.Notification.EXTRA_TITLE)
        val text = extras.getString(android.app.Notification.EXTRA_TEXT)
        
        Log.d(TAG, "Notification from: $packageName")
        Log.d(TAG, "Title: $title")
        Log.d(TAG, "Text: $text")
        
        // Only read WhatsApp messages
        if (packageName.contains("whatsapp") && text != null) {
            // Speak the message
            systemHelper.speak("WhatsApp message: $text")
            
            // Broadcast for MainActivity
            val intent = Intent("JARVIS_NOTIFICATION")
            intent.putExtra("package", packageName)
            intent.putExtra("title", title)
            intent.putExtra("text", text)
            sendBroadcast(intent)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Notification removed
    }
}