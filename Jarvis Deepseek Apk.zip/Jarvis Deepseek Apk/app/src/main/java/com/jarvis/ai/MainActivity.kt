package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.jarvis.ai.adapters.ChatAdapter
import com.jarvis.ai.data.ChatMessage
import com.jarvis.ai.data.UserPreferences
import com.jarvis.ai.engine.EasterEggEngine
import com.jarvis.ai.engine.OfflineAIEngine
import com.jarvis.ai.services.FloatingViewService
import com.jarvis.ai.services.VoiceRecognitionService
import com.jarvis.ai.utils.PermissionManager
import com.jarvis.ai.utils.SystemHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // UI Components
    private lateinit var gifImageView: ImageView
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var timeWeatherText: TextView
    private lateinit var streakText: TextView
    private lateinit var modelStatusText: TextView
    private lateinit var voiceVisualization: View
    private lateinit var statsButton: MaterialButton
    private lateinit var downloadProgressBar: LinearProgressIndicator
    
    // Core Engines
    private lateinit var permissionManager: PermissionManager
    private lateinit var systemHelper: SystemHelper
    private lateinit var easterEggEngine: EasterEggEngine
    private lateinit var offlineAIEngine: OfflineAIEngine
    private lateinit var userPreferences: UserPreferences
    
    // State
    private var isListening = false
    private var currentStreak = 0
    private var chatMessages = mutableListOf<ChatMessage>()
    
    // Permission launcher
    private val multiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            Toast.makeText(this, "✅ सभी permissions मिल गईं", Toast.LENGTH_SHORT).show()
            startVoiceService()
        } else {
            val deniedList = permissions.filter { !it.value }.keys.joinToString(", ")
            Toast.makeText(this, "⚠️ Permissions denied: $deniedList", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initializeViews()
        initializeEngines()
        setupRecyclerView()
        setupListeners()
        checkFirstLaunch()
        updateTimeWeather()
        startFloatingService()
    }
    
    private fun initializeViews() {
        gifImageView = findViewById(R.id.gifJarvis)
        chatRecyclerView = findViewById(R.id.chatRecyclerView)
        timeWeatherText = findViewById(R.id.textTimeWeather)
        streakText = findViewById(R.id.textStreak)
        modelStatusText = findViewById(R.id.textModelStatus)
        voiceVisualization = findViewById(R.id.voiceVisualization)
        statsButton = findViewById(R.id.buttonStats)
        downloadProgressBar = findViewById(R.id.progressDownload)
        
        // Load GIF
        Glide.with(this)
            .asGif()
            .load(R.drawable.jarvis_main_gif)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(gifImageView)
    }
    
    private fun initializeEngines() {
        permissionManager = PermissionManager(this, multiplePermissionsLauncher)
        systemHelper = SystemHelper(this)
        easterEggEngine = EasterEggEngine(this)
        userPreferences = UserPreferences(this)
        offlineAIEngine = OfflineAIEngine(this)
        
        currentStreak = userPreferences.getStreak()
        updateStreak()
    }
    
    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(chatMessages)
        chatRecyclerView.layoutManager = LinearLayoutManager(this)
        chatRecyclerView.adapter = chatAdapter
        
        // Add welcome message
        addJarvisMessage("⚡ Jarvis online. Bolo, sun raha hoon.")
    }
    
    private fun setupListeners() {
        statsButton.setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }
        
        gifImageView.setOnClickListener {
            if (!isListening) {
                startVoiceService()
            } else {
                Toast.makeText(this, "🎤 Already listening...", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun checkFirstLaunch() {
        if (userPreferences.isFirstLaunch()) {
            // Show welcome and permission request
            addJarvisMessage("पहली बार? चल, पहले permissions ले लेता हूँ।")
            permissionManager.requestAllPermissions()
            userPreferences.setFirstLaunch(false)
        } else {
            // Check if model is downloaded
            if (!offlineAIEngine.isModelDownloaded()) {
                showModelDownloadDialog()
            } else {
                startVoiceService()
            }
        }
    }
    
    private fun showModelDownloadDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("📥 Download AI Model")
            .setMessage("Jarvis को 170MB का AI model download करना होगा। WiFi use होगा। Continue?")
            .setPositiveButton("Download") { _, _ ->
                downloadModel()
            }
            .setNegativeButton("Skip (Easter eggs only)") { _, _ ->
                modelStatusText.text = "🟠 OFFLINE (Eggs only)"
                startVoiceService()
            }
            .setCancelable(false)
            .show()
    }
    
    private fun downloadModel() {
        downloadProgressBar.visibility = View.VISIBLE
        modelStatusText.text = "🔵 DOWNLOADING..."
        
        lifecycleScope.launch {
            val success = offlineAIEngine.downloadModel { progress ->
                runOnUiThread {
                    downloadProgressBar.progress = progress
                }
            }
            
            withContext(Dispatchers.Main) {
                downloadProgressBar.visibility = View.GONE
                if (success) {
                    modelStatusText.text = "🔵 ONLINE"
                    addJarvisMessage("✅ Model download complete. Main fully ready hoon.")
                    startVoiceService()
                } else {
                    modelStatusText.text = "🟠 OFFLINE"
                    addJarvisMessage("⚠️ Download failed. WiFi check kar. Phir try kar.")
                }
            }
        }
    }
    
    private fun startVoiceService() {
        if (!permissionManager.hasMicrophonePermission()) {
            permissionManager.requestMicrophonePermission()
            return
        }
        
        val intent = Intent(this, VoiceRecognitionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        isListening = true
        voiceVisualization.setBackgroundResource(R.drawable.bg_listening)
        modelStatusText.text = if (offlineAIEngine.isModelDownloaded()) "🔵 ONLINE" else "🟠 OFFLINE"
        
        // Start floating service if not already running
        startFloatingService()
    }
    
    private fun startFloatingService() {
        if (Settings.canDrawOverlays(this)) {
            val intent = Intent(this, FloatingViewService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }
    
    fun addUserMessage(message: String) {
        runOnUiThread {
            val chatMessage = ChatMessage(
                id = System.currentTimeMillis(),
                message = message,
                isUser = true,
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            )
            chatMessages.add(chatMessage)
            chatAdapter.notifyItemInserted(chatMessages.size - 1)
            chatRecyclerView.smoothScrollToPosition(chatMessages.size - 1)
        }
    }
    
    fun addJarvisMessage(message: String) {
        runOnUiThread {
            val chatMessage = ChatMessage(
                id = System.currentTimeMillis() + 1,
                message = message,
                isUser = false,
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            )
            chatMessages.add(chatMessage)
            chatAdapter.notifyItemInserted(chatMessages.size - 1)
            chatRecyclerView.smoothScrollToPosition(chatMessages.size - 1)
            
            // Speak the message
            systemHelper.speak(message)
            
            // Increment streak
            currentStreak++
            userPreferences.saveStreak(currentStreak)
            updateStreak()
        }
    }
    
    fun processVoiceCommand(command: String) {
        addUserMessage(command)
        
        lifecycleScope.launch {
            // First check easter eggs
            val eggResponse = easterEggEngine.matchEasterEgg(command)
            if (eggResponse != null) {
                addJarvisMessage(eggResponse)
                return@launch
            }
            
            // No egg, use AI if available
            if (offlineAIEngine.isModelDownloaded()) {
                val aiResponse = withContext(Dispatchers.Default) {
                    offlineAIEngine.generateResponse(command)
                }
                addJarvisMessage(aiResponse)
            } else {
                // Fallback response
                addJarvisMessage("Command samajh gaya, par AI model nahi hai. Easter eggs ke liye bol.")
            }
        }
    }
    
    private fun updateTimeWeather() {
        // Simple time update
        val dateFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        timeWeatherText.text = "${dateFormat.format(Date())} · 📍 CP · 26°"
        
        // Update every minute
        timeWeatherText.postDelayed({
            updateTimeWeather()
        }, 60000)
    }
    
    private fun updateStreak() {
        streakText.text = "🔥 $currentStreak"
    }
    
    override fun onResume() {
        super.onResume()
        // Check if overlay permission is needed
        if (!Settings.canDrawOverlays(this)) {
            permissionManager.requestOverlayPermission()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // Don't stop services - they run independently
    }
}