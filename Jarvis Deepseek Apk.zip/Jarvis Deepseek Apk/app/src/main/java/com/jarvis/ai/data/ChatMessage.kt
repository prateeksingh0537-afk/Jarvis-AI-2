package com.jarvis.ai.data

data class ChatMessage(
    val id: Long,
    val message: String,
    val isUser: Boolean,
    val timestamp: String
)