package com.jarvis.ai.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.jarvis.ai.services.VoiceRecognitionService

class WakeWordBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "JARVIS_WAKE_WORD") {
            // Start voice recognition if not running
            val serviceIntent = Intent(context, VoiceRecognitionService::class.java)
            context.startService(serviceIntent)
        }
    }
}