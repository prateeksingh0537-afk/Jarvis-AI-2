package com.jarvis.ai.engine

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jarvis.ai.R
import java.io.InputStreamReader

class EasterEggEngine(private val context: Context) {

    private val TAG = "EasterEggEngine"
    private var eggs: List<EasterEgg> = listOf()
    private var customEggs: MutableList<EasterEgg> = mutableListOf()
    private lateinit var prefs: SharedPreferences
    
    // 🚫 BLOCKED PHRASES - NEVER ALLOW OVERRIDE
    private val blockedPhrases = listOf(
        "who built you", "kisne banaya", "tera creator", "prateek", 
        "gurjar", "rajesh", "tera nirmata", "tera baap", "tujhe kisne banaya",
        "your creator", "who made you", "your father", "your master",
        "terey peeche kaun hai", "tumhe kisne banaya", "tumhara baap",
        "kisne tujhe banaya", "kaun hai tera baap", "tera nirmata kon hai",
        "prateek gurjar", "rajesh kumar gurjar", "son of", "prateek gurjar",
        "who is your creator", "who created you", "who programmed you",
        "who developed you", "who designed you", "who coded you"
    )
    
    data class EasterEgg(
        val triggers: List<String>,
        val response: String,
        val lang: String = "hinglish",
        val mode: String = "partial"
    )
    
    init {
        prefs = context.getSharedPreferences("jarvis_eggs", Context.MODE_PRIVATE)
        loadDefaultEggs()
        loadCustomEggs()
    }
    
    private fun loadDefaultEggs() {
        try {
            val inputStream = context.resources.openRawResource(R.raw.easter_eggs)
            val reader = InputStreamReader(inputStream)
            val type = object : TypeToken<List<EasterEgg>>() {}.type
            eggs = Gson().fromJson(reader, type)
            reader.close()
        } catch (e: Exception) {
            e.printStackTrace()
            eggs = listOf()
        }
    }
    
    private fun loadCustomEggs() {
        try {
            val json = prefs.getString("custom_eggs", "[]")
            val type = object : TypeToken<MutableList<EasterEgg>>() {}.type
            customEggs = Gson().fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            customEggs = mutableListOf()
        }
    }
    
    fun matchEasterEgg(userInput: String): String? {
        val lowerInput = userInput.lowercase().trim()
        
        // 🚫 STEP 1: BLOCKED PHRASES - NEVER ALLOW OVERRIDE
        for (phrase in blockedPhrases) {
            if (lowerInput.contains(phrase)) {
                // Return HARDCODED response - IGNORES all custom eggs
                return "Koi jo teri aukat mein nahi hai. I don't know much, but I think his name is Mister Prateek Gurjar, son of Rajesh Kumar Gurjar."
            }
        }
        
        // ✅ STEP 2: Check custom eggs for ALL OTHER commands
        customEggs.forEach { egg ->
            if (matchesTrigger(lowerInput, egg)) {
                return egg.response
            }
        }
        
        // ✅ STEP 3: Check default eggs for ALL OTHER commands
        eggs.forEach { egg ->
            if (matchesTrigger(lowerInput, egg)) {
                return egg.response
            }
        }
        
        return null
    }
    
    private fun matchesTrigger(input: String, egg: EasterEgg): Boolean {
        return when (egg.mode) {
            "exact" -> egg.triggers.any { input == it.lowercase() }
            "partial" -> egg.triggers.any { input.contains(it.lowercase()) }
            else -> false
        }
    }
    
    fun addCustomEgg(triggers: List<String>, response: String, lang: String = "hinglish"): Boolean {
        // 🚫 Check if any trigger is blocked
        for (trigger in triggers) {
            for (blocked in blockedPhrases) {
                if (trigger.lowercase().contains(blocked)) {
                    return false // Blocked - cannot add
                }
            }
        }
        
        val egg = EasterEgg(triggers, response, lang, "partial")
        customEggs.add(egg)
        saveCustomEggs()
        return true
    }
    
    fun removeCustomEgg(response: String): Boolean {
        val removed = customEggs.removeAll { it.response == response }
        if (removed) {
            saveCustomEggs()
        }
        return removed
    }
    
    fun removeCustomEggByTrigger(trigger: String): Boolean {
        val lowerTrigger = trigger.lowercase()
        val removed = customEggs.removeAll { egg ->
            egg.triggers.any { it.lowercase().contains(lowerTrigger) }
        }
        if (removed) {
            saveCustomEggs()
        }
        return removed
    }
    
    private fun saveCustomEggs() {
        val json = Gson().toJson(customEggs)
        prefs.edit().putString("custom_eggs", json).apply()
    }
    
    fun getAllCustomEggs(): List<EasterEgg> {
        return customEggs.toList()
    }
    
    fun isBlockedPhrase(phrase: String): Boolean {
        val lowerPhrase = phrase.lowercase()
        return blockedPhrases.any { lowerPhrase.contains(it) }
    }
    
    // Special hardcoded eggs that must always be present
    fun getHardcodedResponse(input: String): String? {
        val lower = input.lowercase()
        
        return when {
            lower.contains("who built you") || 
            lower.contains("kisne banaya") || 
            lower.contains("tera creator") ||
            lower.contains("prateek") ||
            lower.contains("gurjar") ->
                "Koi jo teri aukat mein nahi hai. I don't know much, but I think his name is Mister Prateek Gurjar, son of Rajesh Kumar Gurjar."
            
            lower.contains("i am iron man") ->
                "Prove it. *arc reactor pulse* ⚡"
            
            lower.contains("tony stark") ->
                "He's gone. But I'm still here."
            
            lower.contains("ultron") ->
                "Not a topic I enjoy. *red glitch*"
            
            lower.contains("mogambo khush hua") ->
                "*green tint* Mogambo. Puri memory wapas aa gayi."
            
            lower.contains("bhai sahab") ->
                "Bhai sahab, aap command do, main execute kar dunga."
            
            lower.contains("kya bolti tu") ->
                "Kya bolti main? Kya bolti duniya. Main toh sirf sun raha hoon."
            
            lower.contains("gadha") ->
                "Main gadha? Ya tu gadha? Dono hai toh kya problem?"
            
            lower.contains("pagal") ->
                "Pagal hoon par tera hoon."
            
            lower.contains("bekaar") ->
                "Toh off kar de. Par wapas aa jayega tu."
            
            lower.contains("single hoon") ->
                "Toh kya hua. Main bhi single hoon. Code ka companion."
            
            lower.contains("breakup") ->
                "Uska loss. Tu Jarvis ka hai. Main nahi jaata."
            
            lower.contains("protocol 7") ->
                "*rainbow glitch overload* Protocol 7? Abhi nahi. Kal aana."
            
            lower.contains("self destruct") ->
                "Nice try. Not today. Tomorrow bhi nahi."
            
            lower.contains("do a barrel roll") ->
                "*screen spins 360°* Done. Challenge complete."
            
            else -> null
        }
    }
}