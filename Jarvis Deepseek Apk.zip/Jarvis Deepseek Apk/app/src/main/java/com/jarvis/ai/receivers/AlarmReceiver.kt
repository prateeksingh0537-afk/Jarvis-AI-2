package com.jarvis.ai.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import com.jarvis.ai.utils.SystemHelper

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmType = intent.getStringExtra("alarm_type") ?: "reminder"
        val message = intent.getStringExtra("message") ?: "Alarm!"
        
        // Wake up device
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "Jarvis:AlarmWakeLock"
        )
        wakeLock.acquire(5000)
        
        // Speak the alarm
        val systemHelper = SystemHelper(context)
        systemHelper.speak(message)
        
        // Release wake lock after speaking
        wakeLock.release()
    }
}