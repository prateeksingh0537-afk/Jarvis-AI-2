package com.jarvis.ai.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.ai.MainActivity
import com.jarvis.ai.R
import com.jarvis.ai.receivers.WakeWordBroadcastReceiver
import com.jarvis.ai.utils.SystemHelper
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class VoiceRecognitionService : Service() {

    private val TAG = "VoiceRecognitionService"
    private val CHANNEL_ID = "jarvis_voice_channel"
    private val NOTIFICATION_ID = 1001
    
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = AtomicBoolean(false)
    private var wakeWordDetected = AtomicBoolean(false)
    
    private lateinit var systemHelper: SystemHelper
    private lateinit var handlerThread: HandlerThread
    private lateinit var handler: Handler
    private lateinit var mainHandler: Handler
    
    private var fromLockScreen = false
    
    override fun onCreate() {
        super.onCreate()
        
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        
        systemHelper = SystemHelper(this)
        
        handlerThread = HandlerThread("VoiceRecognitionThread")
        handlerThread.start()
        handler = Handler(handlerThread.looper)
        mainHandler = Handler(Looper.getMainLooper())
        
        initializeSpeechRecognizer()
        startWakeWordDetection()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Jarvis Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setSound(null, null)
                enableVibration(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say 'Jarvis' to wake me up")
            .setSmallIcon(R.drawable.ic_mic)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
    
    private fun initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle) {
                    Log.d(TAG, "Ready for speech")
                }
                
                override fun onBeginningOfSpeech() {
                    Log.d(TAG, "Beginning of speech")
                }
                
                override fun onRmsChanged(rmsdB: Float) {
                    // Update UI with voice visualization
                    updateVoiceVisualization(rmsdB)
                }
                
                override fun onBufferReceived(buffer: ByteArray) {
                    // Handle buffer
                }
                
                override fun onEndOfSpeech() {
                    Log.d(TAG, "End of speech")
                    resetVoiceVisualization()
                }
                
                override fun onError(error: Int) {
                    val errorMessage = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech matched"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                        SpeechRecognizer.ERROR_NETWORK -> "Network error"
                        SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                        else -> "Unknown error: $error"
                    }
                    Log.e(TAG, "Speech recognition error: $errorMessage")
                    
                    // Restart listening after error
                    handler.postDelayed({
                        startListening()
                    }, 1000)
                }
                
                override fun onResults(results: Bundle) {
                    val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val command = matches[0]
                        Log.d(TAG, "Recognized: $command")
                        
                        // Check if this was after wake word or direct command
                        if (wakeWordDetected.get()) {
                            processCommand(command)
                            wakeWordDetected.set(false)
                            // Go back to wake word detection
                            startWakeWordDetection()
                        } else {
                            // This was wake word detection
                            if (command.contains("Jarvis", ignoreCase = true) || 
                                command.contains("जार्विस", ignoreCase = true)) {
                                onWakeWordDetected()
                            } else {
                                // False wake, restart detection
                                startWakeWordDetection()
                            }
                        }
                    }
                }
                
                override fun onPartialResults(partialResults: Bundle) {
                    // Handle partial results
                }
                
                override fun onEvent(eventType: Int, params: Bundle) {
                    // Handle events
                }
            })
        }
    }
    
    private fun startWakeWordDetection() {
        if (isListening.get()) return
        
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN,en-US")
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000)
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
        
        isListening.set(true)
        speechRecognizer?.startListening(intent)
    }
    
    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN,en-US")
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        
        isListening.set(true)
        speechRecognizer?.startListening(intent)
    }
    
    private fun onWakeWordDetected() {
        Log.d(TAG, "Wake word detected!")
        wakeWordDetected.set(true)
        
        // Vibrate to indicate wake
        systemHelper.vibrate(100)
        
        // Speak wake confirmation
        systemHelper.speak("बोलो, सुन रहा हूँ")
        
        // Start command listening
        startListening()
    }
    
    private fun processCommand(command: String) {
        Log.d(TAG, "Processing command: $command")
        
        // Vibrate to acknowledge
        systemHelper.vibrate(50)
        
        // Send command to appropriate activity
        val intent = Intent("JARVIS_COMMAND")
        intent.putExtra("command", command)
        intent.putExtra("from_lock_screen", fromLockScreen)
        sendBroadcast(intent)
        
        // Also try to send to MainActivity if running
        val mainIntent = Intent(this, MainActivity::class.java)
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        mainIntent.putExtra("voice_command", command)
        startActivity(mainIntent)
    }
    
    private fun updateVoiceVisualization(rmsdB: Float) {
        val intent = Intent("JARVIS_VOICE_VIZ")
        intent.putExtra("rms", rmsdB)
        sendBroadcast(intent)
    }
    
    private fun resetVoiceVisualization() {
        val intent = Intent("JARVIS_VOICE_VIZ_RESET")
        sendBroadcast(intent)
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        fromLockScreen = intent?.getBooleanExtra("from_lock_screen", false) ?: false
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        isListening.set(false)
        speechRecognizer?.destroy()
        handlerThread.quitSafely()
    }
}