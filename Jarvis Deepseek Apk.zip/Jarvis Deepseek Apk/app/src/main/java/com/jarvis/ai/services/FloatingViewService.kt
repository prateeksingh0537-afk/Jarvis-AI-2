package com.jarvis.ai.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.bumptech.glide.Glide
import com.jarvis.ai.R
import com.jarvis.ai.data.UserPreferences
import com.jarvis.ai.utils.SystemHelper

class FloatingViewService : Service() {

    private val CHANNEL_ID = "jarvis_floating_channel"
    private val NOTIFICATION_ID = 1002
    
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: FrameLayout
    private lateinit var gifImageView: ImageView
    private lateinit var systemHelper: SystemHelper
    private lateinit var userPreferences: UserPreferences
    
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private var isMuted = false
    
    private val mainHandler = Handler(Looper.getMainLooper())
    
    override fun onCreate() {
        super.onCreate()
        
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        systemHelper = SystemHelper(this)
        userPreferences = UserPreferences(this)
        
        createFloatingView()
        loadSavedPosition()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Jarvis Floating Button",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setSound(null, null)
                enableVibration(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis is here")
            .setContentText("Tap to speak, drag to move")
            .setSmallIcon(R.drawable.ic_jarvis)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
    
    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun createFloatingView() {
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        floatingView = inflater.inflate(R.layout.floating_layout, null) as FrameLayout
        gifImageView = floatingView.findViewById(R.id.floatingGif)
        
        // Load user's GIF preference
        val gifUrl = userPreferences.getFloatingGifUrl()
        Glide.with(this)
            .asGif()
            .load(if (gifUrl.isNotEmpty()) gifUrl else R.drawable.jarvis_floating_gif)
            .into(gifImageView)
        
        // Set up touch listener for dragging
        floatingView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = windowManagerParams.x
                    initialY = windowManagerParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    
                    // Haptic feedback
                    systemHelper.vibrate(20)
                    true
                }
                
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isDragging = true
                    }
                    
                    // Update position
                    windowManagerParams.x = initialX + deltaX
                    windowManagerParams.y = initialY + deltaY
                    windowManager.updateViewLayout(floatingView, windowManagerParams)
                    true
                }
                
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        // Snap to nearest edge
                        snapToEdge()
                        // Save position
                        savePosition()
                    } else {
                        // Tap action
                        onFloatingViewTap()
                    }
                    isDragging = false
                    true
                }
                
                else -> false
            }
        }
        
        // Long press listener for mute
        floatingView.setOnLongClickListener {
            toggleMute()
            true
        }
        
        // Add to window
        windowManager.addView(floatingView, windowManagerParams)
    }
    
    private val windowManagerParams: WindowManager.LayoutParams by lazy {
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 200
        }
    }
    
    private fun loadSavedPosition() {
        val position = userPreferences.getFloatingPosition()
        windowManagerParams.x = position.x
        windowManagerParams.y = position.y
        windowManager.updateViewLayout(floatingView, windowManagerParams)
    }
    
    private fun savePosition() {
        userPreferences.saveFloatingPosition(
            windowManagerParams.x,
            windowManagerParams.y
        )
    }
    
    private fun snapToEdge() {
        val display = windowManager.defaultDisplay
        val size = android.graphics.Point()
        display.getSize(size)
        
        val screenWidth = size.x
        val viewWidth = floatingView.width
        
        // Determine which edge is closer
        val distToLeft = windowManagerParams.x
        val distToRight = screenWidth - (windowManagerParams.x + viewWidth)
        
        if (distToLeft < distToRight) {
            // Snap to left
            windowManagerParams.x = 0
        } else {
            // Snap to right
            windowManagerParams.x = screenWidth - viewWidth
        }
        
        // Keep within screen bounds vertically
        if (windowManagerParams.y < 0) {
            windowManagerParams.y = 0
        } else if (windowManagerParams.y + floatingView.height > size.y) {
            windowManagerParams.y = size.y - floatingView.height
        }
        
        windowManager.updateViewLayout(floatingView, windowManagerParams)
    }
    
    private fun onFloatingViewTap() {
        // Wake up Jarvis
        systemHelper.vibrate(50)
        
        // Start voice recognition if not already running
        val intent = Intent(this, VoiceRecognitionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        // Animate tap feedback
        gifImageView.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction {
                gifImageView.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }
            .start()
    }
    
    private fun toggleMute() {
        isMuted = !isMuted
        
        // Change GIF appearance to indicate muted state
        if (isMuted) {
            gifImageView.alpha = 0.5f
            systemHelper.speak("Mic off")
        } else {
            gifImageView.alpha = 1.0f
            systemHelper.speak("Mic on")
        }
        
        // Save mute state
        userPreferences.setMuted(isMuted)
    }
    
    fun updateOnlineStatus(isOnline: Boolean) {
        mainHandler.post {
            // Add a status indicator (small dot)
            // This would be implemented in the layout
        }
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }
}