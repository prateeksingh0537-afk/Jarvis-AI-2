package com.jarvis.ai.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.jarvis.ai.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class ModelDownloadService : LifecycleService() {

    private val CHANNEL_ID = "jarvis_download_channel"
    private val NOTIFICATION_ID = 1003
    
    companion object {
        const val ACTION_DOWNLOAD = "download"
        const val ACTION_CANCEL = "cancel"
        const val EXTRA_MODEL_URL = "model_url"
        const val EXTRA_MODEL_FILENAME = "model_filename"
        const val PROGRESS_UPDATE = "progress_update"
    }
    
    private var isDownloading = false
    private var currentProgress = 0
    
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        
        when (intent?.action) {
            ACTION_DOWNLOAD -> {
                val url = intent.getStringExtra(EXTRA_MODEL_URL)
                val filename = intent.getStringExtra(EXTRA_MODEL_FILENAME)
                if (!url.isNullOrEmpty() && !filename.isNullOrEmpty()) {
                    startForeground(NOTIFICATION_ID, createNotification(0))
                    downloadModel(url, filename)
                }
            }
            ACTION_CANCEL -> {
                stopDownload()
            }
        }
        
        return START_NOT_STICKY
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Jarvis Model Download",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setSound(null, null)
                enableVibration(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Downloading AI Model")
            .setContentText("Progress: $progress%")
            .setSmallIcon(R.drawable.ic_download)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setProgress(100, progress, false)
            .build()
    }
    
    private fun downloadModel(urlString: String, filename: String) {
        if (isDownloading) return
        
        isDownloading = true
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val url = URL(urlString)
                    val connection = url.openConnection() as HttpURLConnection
                    connection.connect()
                    
                    val fileLength = connection.contentLength
                    val inputStream = connection.inputStream
                    
                    val outputFile = File(filesDir, filename)
                    val outputStream = FileOutputStream(outputFile)
                    
                    val buffer = ByteArray(4096)
                    var total: Long = 0
                    var count: Int
                    
                    while (inputStream.read(buffer).also { count = it } != -1) {
                        if (!isDownloading) {
                            break
                        }
                        total += count
                        outputStream.write(buffer, 0, count)
                        
                        val progress = (total * 100 / fileLength).toInt()
                        if (progress > currentProgress) {
                            currentProgress = progress
                            updateNotification(progress)
                            sendProgressBroadcast(progress)
                        }
                    }
                    
                    outputStream.close()
                    inputStream.close()
                    
                    if (isDownloading) {
                        // Download complete
                        sendProgressBroadcast(100)
                        stopForeground(false)
                        stopSelf()
                    }
                    
                } catch (e: Exception) {
                    e.printStackTrace()
                    sendProgressBroadcast(-1) // Error
                    stopForeground(false)
                    stopSelf()
                }
            }
        }
    }
    
    private fun updateNotification(progress: Int) {
        val notification = createNotification(progress)
        val notificationManager = NotificationManagerCompat.from(this)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }
    
    private fun sendProgressBroadcast(progress: Int) {
        val intent = Intent(PROGRESS_UPDATE)
        intent.putExtra("progress", progress)
        sendBroadcast(intent)
    }
    
    private fun stopDownload() {
        isDownloading = false
        stopForeground(false)
        stopSelf()
    }
    
    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}