package com.jarvis.ai.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.dataStore by preferencesDataStore(name = "jarvis_prefs")

class UserPreferences(private val context: Context) {

    companion object {
        private val FIRST_LAUNCH = booleanPreferencesKey("first_launch")
        private val STREAK = intPreferencesKey("streak")
        private val LONGEST_STREAK = intPreferencesKey("longest_streak")
        private val CURRENT_USER_ID = intPreferencesKey("current_user_id")
        private val FLOATING_X = intPreferencesKey("floating_x")
        private val FLOATING_Y = intPreferencesKey("floating_y")
        private val FLOATING_GIF_URL = stringPreferencesKey("floating_gif_url")
        private val MAIN_GIF_URL = stringPreferencesKey("main_gif_url")
        private val LOCK_GIF_URL = stringPreferencesKey("lock_gif_url")
        private val IS_MUTED = booleanPreferencesKey("is_muted")
        private val AI_MODEL_DOWNLOADED = booleanPreferencesKey("ai_model_downloaded")
        private val SELECTED_VOICE = stringPreferencesKey("selected_voice")
        private val SPEECH_RATE = floatPreferenceKey("speech_rate")
    }

    fun isFirstLaunch(): Boolean {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[FIRST_LAUNCH] ?: true
            }.first()
        }
    }

    suspend fun setFirstLaunch(value: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[FIRST_LAUNCH] = value
        }
    }

    fun getStreak(): Int {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[STREAK] ?: 0
            }.first()
        }
    }

    suspend fun saveStreak(streak: Int) {
        context.dataStore.edit { prefs ->
            prefs[STREAK] = streak
            if (streak > (prefs[LONGEST_STREAK] ?: 0)) {
                prefs[LONGEST_STREAK] = streak
            }
        }
    }

    fun getLongestStreak(): Int {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[LONGEST_STREAK] ?: 0
            }.first()
        }
    }

    fun getCurrentUserId(): Int {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[CURRENT_USER_ID] ?: 0
            }.first()
        }
    }

    suspend fun setCurrentUserId(userId: Int) {
        context.dataStore.edit { prefs ->
            prefs[CURRENT_USER_ID] = userId
        }
    }

    fun getFloatingPosition(): Pair<Int, Int> {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                Pair(
                    prefs[FLOATING_X] ?: 0,
                    prefs[FLOATING_Y] ?: 200
                )
            }.first()
        }
    }

    suspend fun saveFloatingPosition(x: Int, y: Int) {
        context.dataStore.edit { prefs ->
            prefs[FLOATING_X] = x
            prefs[FLOATING_Y] = y
        }
    }

    fun getFloatingGifUrl(): String {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[FLOATING_GIF_URL] ?: ""
            }.first()
        }
    }

    suspend fun setFloatingGifUrl(url: String) {
        context.dataStore.edit { prefs ->
            prefs[FLOATING_GIF_URL] = url
        }
    }

    fun getMainGifUrl(): String {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[MAIN_GIF_URL] ?: ""
            }.first()
        }
    }

    suspend fun setMainGifUrl(url: String) {
        context.dataStore.edit { prefs ->
            prefs[MAIN_GIF_URL] = url
        }
    }

    fun getLockGifUrl(): String {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[LOCK_GIF_URL] ?: ""
            }.first()
        }
    }

    suspend fun setLockGifUrl(url: String) {
        context.dataStore.edit { prefs ->
            prefs[LOCK_GIF_URL] = url
        }
    }

    fun isMuted(): Boolean {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[IS_MUTED] ?: false
            }.first()
        }
    }

    suspend fun setMuted(muted: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_MUTED] = muted
        }
    }

    fun isModelDownloaded(): Boolean {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[AI_MODEL_DOWNLOADED] ?: false
            }.first()
        }
    }

    suspend fun setModelDownloaded(downloaded: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[AI_MODEL_DOWNLOADED] = downloaded
        }
    }

    fun getSelectedVoice(): String {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[SELECTED_VOICE] ?: "male"
            }.first()
        }
    }

    suspend fun setSelectedVoice(voice: String) {
        context.dataStore.edit { prefs ->
            prefs[SELECTED_VOICE] = voice
        }
    }

    fun getSpeechRate(): Float {
        return runBlocking {
            context.dataStore.data.map { prefs ->
                prefs[SPEECH_RATE] ?: 1.0f
            }.first()
        }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { prefs ->
            prefs[SPEECH_RATE] = rate
        }
    }
}

// Helper for float preferences
private fun floatPreferenceKey(name: String) = object : androidx.datastore.preferences.core.Preference.DataType<Float> {
    override fun getName(): String = name
    override fun getDefaultValue(): Float = 1.0f
}