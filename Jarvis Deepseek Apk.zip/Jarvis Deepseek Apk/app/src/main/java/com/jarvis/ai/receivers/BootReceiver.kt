package com.jarvis.ai.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.jarvis.ai.services.FloatingViewService
import com.jarvis.ai.services.VoiceRecognitionService

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_QUICKBOOT_POWERON) {
            
            // Start voice service after boot
            val voiceIntent = Intent(context, VoiceRecognitionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(voiceIntent)
            } else {
                context.startService(voiceIntent)
            }
            
            // Start floating button after boot
            val floatIntent = Intent(context, FloatingViewService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(floatIntent)
            } else {
                context.startService(floatIntent)
            }
        }
    }
}