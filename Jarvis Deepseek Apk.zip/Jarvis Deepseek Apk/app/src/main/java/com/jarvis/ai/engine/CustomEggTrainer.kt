package com.jarvis.ai.engine

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.util.regex.Pattern

class CustomEggTrainer(private val context: Context) {

    private val easterEggEngine = EasterEggEngine(context)
    
    private val _trainingResult = MutableLiveData<String>()
    val trainingResult: LiveData<String> = _trainingResult
    
    // Patterns for training commands
    private val trainPattern1 = Pattern.compile("(?i).*jab\\s+(.+?)\\s+toh\\s+(.+?)\\s+bole.*")
    private val trainPattern2 = Pattern.compile("(?i).*when\\s+(.+?)\\s+say\\s+(.+?)\\s+you\\s+say.*")
    private val trainPattern3 = Pattern.compile("(?i).*learn\\s+new\\s+command\\s*[:\\s]+(.+?)\\s*[:\\s]+(.+)")
    
    // 🚫 BLOCKED PHRASES (same as EasterEggEngine)
    private val blockedPhrases = listOf(
        "who built you", "kisne banaya", "tera creator", "prateek", 
        "gurjar", "rajesh", "tera nirmata", "tera baap", "tujhe kisne banaya",
        "your creator", "who made you", "your father", "your master",
        "prateek gurjar", "rajesh kumar gurjar", "son of"
    )
    
    fun processTrainingCommand(userInput: String): String {
        val lowerInput = userInput.lowercase()
        
        // Check for blocked phrases first
        for (blocked in blockedPhrases) {
            if (lowerInput.contains(blocked)) {
                _trainingResult.value = "❌ Yeh command change nahi kar sakte. Ye permanent hai."
                return "❌ Yeh command change nahi kar sakte. Ye permanent hai."
            }
        }
        
        // Try different patterns
        var matchFound = false
        var trigger = ""
        var response = ""
        
        // Pattern 1: "Jab X bolein toh Y bole"
        val matcher1 = trainPattern1.matcher(userInput)
        if (matcher1.matches()) {
            trigger = matcher1.group(1).trim()
            response = matcher1.group(2).trim()
            matchFound = true
        }
        
        // Pattern 2: "When X say you say Y"
        if (!matchFound) {
            val matcher2 = trainPattern2.matcher(userInput)
            if (matcher2.matches()) {
                trigger = matcher2.group(1).trim()
                response = matcher2.group(2).trim()
                matchFound = true
            }
        }
        
        // Pattern 3: "Learn new command: X : Y"
        if (!matchFound) {
            val matcher3 = trainPattern3.matcher(userInput)
            if (matcher3.matches()) {
                trigger = matcher3.group(1).trim()
                response = matcher3.group(2).trim()
                matchFound = true
            }
        }
        
        if (!matchFound || trigger.isEmpty() || response.isEmpty()) {
            _trainingResult.value = "Samajh nahi aaya. 'Jarvis, jab X bolein toh Y bole' bolo."
            return "Samajh nahi aaya. 'Jarvis, jab X bolein toh Y bole' bolo."
        }
        
        // 🚫 Double-check trigger for blocked phrases
        if (easterEggEngine.isBlockedPhrase(trigger)) {
            _trainingResult.value = "❌ Yeh command change nahi kar sakte. Ye permanent hai."
            return "❌ Yeh command change nahi kar sakte. Ye permanent hai."
        }
        
        // Save the custom egg
        val success = easterEggEngine.addCustomEgg(listOf(trigger), response)
        
        if (success) {
            val resultMsg = "✅ Sikh liya. Jab '$trigger' bologe toh '$response' bolunga."
            _trainingResult.value = resultMsg
            return resultMsg
        } else {
            val errorMsg = "❌ Yeh command add nahi kar sakte. Ye reserved hai."
            _trainingResult.value = errorMsg
            return errorMsg
        }
    }
    
    fun processDeleteCommand(userInput: String): String {
        val lowerInput = userInput.lowercase()
        
        // Check for blocked phrases
        for (blocked in blockedPhrases) {
            if (lowerInput.contains(blocked)) {
                _trainingResult.value = "❌ Yeh command delete nahi kar sakte. Ye permanent hai."
                return "❌ Yeh command delete nahi kar sakte. Ye permanent hai."
            }
        }
        
        // Pattern: "Jarvis, yeh egg hata do [response]"
        var responseToDelete = ""
        
        if (lowerInput.contains("yeh egg hata do") || lowerInput.contains("ye command hata do")) {
            // Extract what to delete
            val patterns = listOf("yeh egg hata do", "ye command hata do", "yeh hata do")
            for (pattern in patterns) {
                val index = lowerInput.indexOf(pattern)
                if (index >= 0) {
                    responseToDelete = userInput.substring(index + pattern.length).trim()
                    break
                }
            }
        }
        
        if (responseToDelete.isEmpty()) {
            // Try to get the full command after "hata do"
            val words = userInput.split(" ")
            val hataIndex = words.indexOfFirst { it.equals("hata", ignoreCase = true) }
            if (hataIndex >= 0 && hataIndex + 1 < words.size) {
                responseToDelete = words.subList(hataIndex + 1, words.size).joinToString(" ")
            }
        }
        
        if (responseToDelete.isEmpty()) {
            _trainingResult.value = "क्या हटाना है? 'Jarvis, yeh egg hata do [response]' bolo."
            return "क्या हटाना है? 'Jarvis, yeh egg hata do [response]' bolo."
        }
        
        val removed = easterEggEngine.removeCustomEgg(responseToDelete)
        
        if (removed) {
            val resultMsg = "✅ '$responseToDelete' wala egg hata diya."
            _trainingResult.value = resultMsg
            return resultMsg
        } else {
            val errorMsg = "❌ '$responseToDelete' wala egg mila nahi."
            _trainingResult.value = errorMsg
            return errorMsg
        }
    }
    
    fun processListCommand(): String {
        val customEggs = easterEggEngine.getAllCustomEggs()
        
        if (customEggs.isEmpty()) {
            return "Abhi koi custom egg nahi hai. 'Jarvis, jab X bolein toh Y bole' bolke naya bana."
        }
        
        val sb = StringBuilder("📋 तेरे custom eggs:\n")
        for ((index, egg) in customEggs.withIndex()) {
            sb.append("${index + 1}. ")
            sb.append("'${egg.triggers.joinToString("/")}' → ")
            sb.append("'${egg.response}'")
            sb.append("\n")
        }
        return sb.toString()
    }
    
    fun processResetCommand(userInput: String): String {
        val lowerInput = userInput.lowercase()
        
        // Check for blocked phrases
        for (blocked in blockedPhrases) {
            if (lowerInput.contains(blocked)) {
                _trainingResult.value = "❌ Yeh command reset nahi kar sakte. Ye permanent hai."
                return "❌ Yeh command reset nahi kar sakte. Ye permanent hai."
            }
        }
        
        // Pattern: "Jarvis, reset [trigger] wala egg"
        var triggerToReset = ""
        
        val patterns = listOf("reset", "wapis kar de", "pehle jaisa kar")
        for (pattern in patterns) {
            val index = lowerInput.indexOf(pattern)
            if (index >= 0) {
                triggerToReset = userInput.substring(index + pattern.length).trim()
                break
            }
        }
        
        triggerToReset = triggerToReset.replace("wala egg", "").replace("egg", "").trim()
        
        if (triggerToReset.isEmpty()) {
            _trainingResult.value = "कौन सा egg reset karna hai? 'Jarvis, reset [trigger] wala egg' bolo."
            return "कौन सा egg reset karna hai? 'Jarvis, reset [trigger] wala egg' bolo."
        }
        
        val removed = easterEggEngine.removeCustomEggByTrigger(triggerToReset)
        
        if (removed) {
            val resultMsg = "✅ '$triggerToReset' wala egg reset kar diya. Ab pehle wala response aayega."
            _trainingResult.value = resultMsg
            return resultMsg
        } else {
            val errorMsg = "❌ '$triggerToReset' wala custom egg mila nahi."
            _trainingResult.value = errorMsg
            return errorMsg
        }
    }
}