#!/bin/bash
# =====================================================================
# JARVIS ANDROID - ULTIMATE ERROR‑HANDLING BUILD SCRIPT
# Created by: Prateek Gurjar, son of Rajesh Kumar Gurjar
# This script will recover from any error and build your APK.
# =====================================================================

set -e  # Exit immediately if any command fails
trap 'echo -e "\033[0;31m❌ Script interrupted. Please check the errors above.\033[0m"; exit 1' INT TERM

# Color codes for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

print_step() {
    echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
}

print_error() {
    echo -e "${RED}❌ ERROR: $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# ---------------------------------------------------------------------
# 1. Locate the project directory
# ---------------------------------------------------------------------
print_step "Checking project directory"

if [ ! -f "app/build.gradle" ]; then
    echo -e "${YELLOW}⚠️  app/build.gradle not found in current directory.${NC}"
    if [ -d "$HOME/jarvis-android" ]; then
        echo -e "${YELLOW}   Switching to ~/jarvis-android${NC}"
        cd "$HOME/jarvis-android"
    else
        print_error "Cannot find jarvis-android folder. Please run this script from the correct directory."
        exit 1
    fi
fi

PROJECT_DIR=$(pwd)
print_success "Project directory: $PROJECT_DIR"

# ---------------------------------------------------------------------
# 2. Java installation & environment
# ---------------------------------------------------------------------
print_step "Setting up Java"

# Install Java if missing
if ! command -v java &> /dev/null; then
    echo -e "${YELLOW}Java not found. Installing openjdk-17...${NC}"
    pkg update -y && pkg install -y openjdk-17 wget unzip
    if [ $? -ne 0 ]; then
        print_error "Failed to install Java. Check your internet connection."
        exit 1
    fi
else
    echo -e "${GREEN}Java already installed.${NC}"
fi

# Set JAVA_HOME and verify version
export JAVA_HOME=/data/data/com.termux/files/usr/lib/jvm/java-17-openjdk
export PATH="$JAVA_HOME/bin:$PATH"

JAVA_VERSION=$(java -version 2>&1 | head -1)
if [[ ! "$JAVA_VERSION" == *"17"* ]]; then
    print_error "Java version is not 17. Found: $JAVA_VERSION"
    exit 1
fi
print_success "Java 17 configured: $JAVA_VERSION"

# ---------------------------------------------------------------------
# 3. Android SDK setup
# ---------------------------------------------------------------------
print_step "Setting up Android SDK"

export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

# Download command line tools if missing
if [ ! -d "$ANDROID_HOME/cmdline-tools" ]; then
    echo -e "${YELLOW}Downloading Android SDK command line tools...${NC}"
    mkdir -p "$ANDROID_HOME/cmdline-tools"
    cd "$HOME"
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    if [ $? -ne 0 ]; then
        print_error "Failed to download SDK tools."
        exit 1
    fi
    unzip -q commandlinetools-linux-11076708_latest.zip -d "$ANDROID_HOME/cmdline-tools"
    mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
    rm commandlinetools-linux-11076708_latest.zip
    cd "$PROJECT_DIR"
    print_success "SDK tools downloaded."
else
    print_success "SDK tools already present."
fi

# Accept all licenses (non‑interactive)
echo -e "${YELLOW}Accepting Android SDK licenses...${NC}"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null 2>&1 || {
    print_error "License acceptance failed. Trying manual fallback..."
    mkdir -p "$ANDROID_HOME/licenses"
    cat > "$ANDROID_HOME/licenses/android-sdk-license" << 'EOF'
8933bad161af4178b1185d1a37fbf41ea5269c55
d56f5187479451eabf01fb78af6dfcb131a6481e
24333f8a63b6825ea9c5514f83c2829b004d1fee
EOF
    cat > "$ANDROID_HOME/licenses/android-sdk-preview-license" << 'EOF'
84831b9409646a918e30573bab4c9c91346d8abd
504667f4c0de7af1a06de9f4b1727b84351f2910
EOF
    print_success "Manual license files created."
}

# Install required SDK components
echo -e "${YELLOW}Installing SDK components (platform-34, build-tools)...${NC}"
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-34" "build-tools;34.0.0" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    print_error "Failed to install SDK components. Check your internet connection."
    exit 1
fi
print_success "SDK components installed."

# ---------------------------------------------------------------------
# 4. Create local.properties
# ---------------------------------------------------------------------
print_step "Creating local.properties"
echo "sdk.dir=$ANDROID_HOME" > local.properties
print_success "local.properties created."

# ---------------------------------------------------------------------
# 5. Fix dependencies in app/build.gradle
# ---------------------------------------------------------------------
print_step "Fixing dependencies"

if [ ! -f "app/build.gradle" ]; then
    print_error "app/build.gradle not found!"
    exit 1
fi

# Replace wrong ML Kit dependency
if grep -q "com.google.mlkit:genai:1.0.0" app/build.gradle; then
    sed -i 's/com.google.mlkit:genai:1.0.0/com.google.mlkit:genai-prompt:1.0.0-alpha1/g' app/build.gradle
    print_success "ML Kit dependency fixed."
else
    print_success "ML Kit dependency already correct."
fi

# Replace wrong MediaPipe version
if grep -q "com.google.mediapipe:tasks-genai:0.10.0" app/build.gradle; then
    sed -i 's/com.google.mediapipe:tasks-genai:0.10.0/com.google.mediapipe:tasks-genai:0.10.15/g' app/build.gradle
    print_success "MediaPipe dependency fixed."
else
    print_success "MediaPipe dependency already correct."
fi

# Ensure google() repository is in settings.gradle
if [ -f "settings.gradle" ]; then
    if ! grep -q "google()" settings.gradle; then
        sed -i '/repositories {/a \        google()' settings.gradle
        print_success "google() repository added."
    else
        print_success "google() repository already present."
    fi
else
    print_error "settings.gradle not found!"
    exit 1
fi

# ---------------------------------------------------------------------
# 6. Prepare Gradle wrapper
# ---------------------------------------------------------------------
print_step "Preparing Gradle"

if [ ! -f "gradlew" ]; then
    print_error "gradlew not found! Please ensure you have the Gradle wrapper."
    exit 1
fi

chmod +x gradlew
print_success "gradlew made executable."

# Kill any existing Gradle daemons to free memory
bash gradlew --stop > /dev/null 2>&1 || true
print_success "Stopped old Gradle daemons."

# Clean project (remove old builds)
echo -e "${YELLOW}Cleaning project...${NC}"
bash gradlew clean > /dev/null 2>&1
print_success "Project cleaned."

# ---------------------------------------------------------------------
# 7. Build the APK
# ---------------------------------------------------------------------
print_step "Building APK (this will take 5‑15 minutes)"

# Set memory limits to avoid out‑of‑memory errors
export GRADLE_OPTS="-Xmx1024m -Dorg.gradle.daemon=false"

# Run the build
bash gradlew assembleDebug --no-daemon

if [ $? -eq 0 ]; then
    print_success "Build completed successfully."
else
    print_error "Build failed. Please check the error messages above."
    exit 1
fi

# ---------------------------------------------------------------------
# 8. Copy APK to Downloads
# ---------------------------------------------------------------------
print_step "Copying APK to Downloads"

APK_SOURCE="app/build/outputs/apk/debug/app-debug.apk"
APK_DEST="/sdcard/Download/Jarvis.apk"

if [ -f "$APK_SOURCE" ]; then
    cp "$APK_SOURCE" "$APK_DEST"
    APK_SIZE=$(ls -lh "$APK_SOURCE" | awk '{print $5}')
    print_success "APK copied to $APK_DEST"
else
    print_error "APK file not found at $APK_SOURCE"
    exit 1
fi

# ---------------------------------------------------------------------
# 9. Final success message
# ---------------------------------------------------------------------
echo ""
echo -e "${PURPLE}════════════════════════════════════════════════════════════${NC}"
echo -e "${PURPLE}     🎉 JARVIS ANDROID - BUILD COMPLETE! 🎉${NC}"
echo -e "${PURPLE}════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${CYAN}  📱 APK Location: $APK_DEST${NC}"
echo -e "${CYAN}  📦 File Size: $APK_SIZE${NC}"
echo ""
echo -e "${CYAN}  👤 Created by: Prateek Gurjar${NC}"
echo -e "${CYAN}  👦 son of Rajesh Kumar Gurjar${NC}"
echo ""
echo -e "${GREEN}✅ JARVIS IS READY TO INSTALL!${NC}"
echo -e "${GREEN}   Open Files app → Downloads → tap Jarvis.apk${NC}"